#!/bin/bash

if [  -n "${ZSH_VERSION:-}" ]; then
    DIRNAME="$(readlink -f -- "${(%):-%x}")"
    APPS_HOME=$(dirname $DIRNAME)
    export APPS_HOME
else
    export APPS_HOME="$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")"
fi

if [[ $* == *--clean* ]]
then
    rm -rf "$APPS_HOME/report"
fi

if [[ $* == *--report_dir* ]]
then
    export REPORT_HOME=$2
else
    mkdir -p "$APPS_HOME/report"
    export REPORT_HOME=$APPS_HOME/report
fi

if [[ $* == *--help* || $* == *-h* ]]; then
    echo "Usage: test_script.sh [--report_dir] [--verbose] [--clean] [--help | -h]"
        echo " Generates output results - this is the only action if no options are specified"
        echo "The options are:"
        echo " --report_dir        Select path for report (absolute path). Default is the repo home"
        echo " --clean             Remove report dir in repo home"
        echo " --help | -h         Print this help message and exit"
    exit 0
fi

echo "Collecting results..."

rm -rf BUILD/

echo `date` >> $REPORT_HOME/out.txt

echo "KERNEL=222" >> $REPORT_HOME/out.txt 2>> $REPORT_HOME/err.txt

make clean all run cores=8 kernel=222 2>> $REPORT_HOME/err.txt  | grep -F "[" >> $REPORT_HOME/out.txt

echo "KERNEL=224" >> $REPORT_HOME/out.txt 2>> $REPORT_HOME/err.txt

make clean all run cores=8 kernel=224 2>> $REPORT_HOME/err.txt  | grep -F "[" >> $REPORT_HOME/out.txt

echo "KERNEL=228" >> $REPORT_HOME/out.txt 2>> $REPORT_HOME/err.txt

make clean all run cores=8 kernel=228 2>> $REPORT_HOME/err.txt  | grep -F "[" >> $REPORT_HOME/out.txt

echo "KERNEL=242" >> $REPORT_HOME/out.txt 2>> $REPORT_HOME/err.txt

make clean all run cores=8 kernel=242 2>> $REPORT_HOME/err.txt  | grep -F "[" >> $REPORT_HOME/out.txt

echo "KERNEL=244" >> $REPORT_HOME/out.txt 2>> $REPORT_HOME/err.txt

make clean all run cores=8 kernel=244 2>> $REPORT_HOME/err.txt  | grep -F "[" >> $REPORT_HOME/out.txt

echo "KERNEL=248" >> $REPORT_HOME/out.txt 2>> $REPORT_HOME/err.txt

make clean all run cores=8 kernel=248 2>> $REPORT_HOME/err.txt  | grep -F "[" >> $REPORT_HOME/out.txt

echo "KERNEL=282" >> $REPORT_HOME/out.txt 2>> $REPORT_HOME/err.txt

make clean all run cores=8 kernel=282 2>> $REPORT_HOME/err.txt  | grep -F "[" >> $REPORT_HOME/out.txt

echo "KERNEL=284" >> $REPORT_HOME/out.txt 2>> $REPORT_HOME/err.txt

make clean all run cores=8 kernel=284 2>> $REPORT_HOME/err.txt  | grep -F "[" >> $REPORT_HOME/out.txt

echo "KERNEL=288" >> $REPORT_HOME/out.txt 2>> $REPORT_HOME/err.txt

make clean all run cores=8 kernel=288 2>> $REPORT_HOME/err.txt  | grep -F "[" >> $REPORT_HOME/out.txt

echo "KERNEL=422" >> $REPORT_HOME/out.txt 2>> $REPORT_HOME/err.txt

make clean all run cores=8 kernel=422 2>> $REPORT_HOME/err.txt  | grep -F "[" >> $REPORT_HOME/out.txt

echo "KERNEL=424" >> $REPORT_HOME/out.txt 2>> $REPORT_HOME/err.txt

make clean all run cores=8 kernel=424 2>> $REPORT_HOME/err.txt  | grep -F "[" >> $REPORT_HOME/out.txt

echo "KERNEL=428" >> $REPORT_HOME/out.txt 2>> $REPORT_HOME/err.txt

make clean all run cores=8 kernel=428 2>> $REPORT_HOME/err.txt  | grep -F "[" >> $REPORT_HOME/out.txt

echo "KERNEL=442" >> $REPORT_HOME/out.txt 2>> $REPORT_HOME/err.txt

make clean all run cores=8 kernel=442 2>> $REPORT_HOME/err.txt  | grep -F "[" >> $REPORT_HOME/out.txt

echo "KERNEL=444" >> $REPORT_HOME/out.txt 2>> $REPORT_HOME/err.txt

make clean all run cores=8 kernel=444 2>> $REPORT_HOME/err.txt  | grep -F "[" >> $REPORT_HOME/out.txt

echo "KERNEL=448" >> $REPORT_HOME/out.txt 2>> $REPORT_HOME/err.txt

make clean all run cores=8 kernel=448 2>> $REPORT_HOME/err.txt  | grep -F "[" >> $REPORT_HOME/out.txt

echo "KERNEL=482" >> $REPORT_HOME/out.txt 2>> $REPORT_HOME/err.txt

make clean all run cores=8 kernel=482 2>> $REPORT_HOME/err.txt  | grep -F "[" >> $REPORT_HOME/out.txt

echo "KERNEL=484" >> $REPORT_HOME/out.txt 2>> $REPORT_HOME/err.txt

make clean all run cores=8 kernel=484 2>> $REPORT_HOME/err.txt  | grep -F "[" >> $REPORT_HOME/out.txt

echo "KERNEL=488" >> $REPORT_HOME/out.txt 2>> $REPORT_HOME/err.txt

make clean all run cores=8 kernel=488 2>> $REPORT_HOME/err.txt  | grep -F "[" >> $REPORT_HOME/out.txt

echo "KERNEL=822" >> $REPORT_HOME/out.txt 2>> $REPORT_HOME/err.txt

make clean all run cores=8 kernel=822 2>> $REPORT_HOME/err.txt  | grep -F "[" >> $REPORT_HOME/out.txt

echo "KERNEL=824" >> $REPORT_HOME/out.txt 2>> $REPORT_HOME/err.txt

make clean all run cores=8 kernel=824 2>> $REPORT_HOME/err.txt  | grep -F "[" >> $REPORT_HOME/out.txt

echo "KERNEL=828" >> $REPORT_HOME/out.txt 2>> $REPORT_HOME/err.txt

make clean all run cores=8 kernel=828 2>> $REPORT_HOME/err.txt  | grep -F "[" >> $REPORT_HOME/out.txt

echo "KERNEL=842" >> $REPORT_HOME/out.txt 2>> $REPORT_HOME/err.txt

make clean all run cores=8 kernel=842 2>> $REPORT_HOME/err.txt  | grep -F "[" >> $REPORT_HOME/out.txt

echo "KERNEL=844" >> $REPORT_HOME/out.txt 2>> $REPORT_HOME/err.txt

make clean all run cores=8 kernel=844 2>> $REPORT_HOME/err.txt  | grep -F "[" >> $REPORT_HOME/out.txt

echo "KERNEL=848" >> $REPORT_HOME/out.txt 2>> $REPORT_HOME/err.txt

make clean all run cores=8 kernel=848 2>> $REPORT_HOME/err.txt  | grep -F "[" >> $REPORT_HOME/out.txt

echo "KERNEL=882" >> $REPORT_HOME/out.txt 2>> $REPORT_HOME/err.txt

make clean all run cores=8 kernel=882 2>> $REPORT_HOME/err.txt  | grep -F "[" >> $REPORT_HOME/out.txt

echo "KERNEL=884" >> $REPORT_HOME/out.txt 2>> $REPORT_HOME/err.txt

make clean all run cores=8 kernel=884 2>> $REPORT_HOME/err.txt  | grep -F "[" >> $REPORT_HOME/out.txt

echo "KERNEL=888" >> $REPORT_HOME/out.txt 2>> $REPORT_HOME/err.txt

make clean all run cores=8 kernel=888 2>> $REPORT_HOME/err.txt  | grep -F "[" >> $REPORT_HOME/out.txt

echo "...done"
