/*
 * layer_template.c
 * Alessio Burrello <alessio.burrello@unibo.it>
 *
 * Copyright (C) 2018-2020 University of Bologna
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License. 
 */

#include "mchan_test.h"
#include "pulp_nn_kernels.h"
#include "layerConv.h"

void layerConv_Tiling_Blocking(
  void *args
) 
{
  unsigned int *real_arg = (unsigned int *) args;
  unsigned int x =(unsigned int)  real_arg[0];
  unsigned int W =(unsigned int)  real_arg[1];
  unsigned int y =(unsigned int)  real_arg[2];
  unsigned int x_L1 =(unsigned int)  real_arg[4];
  unsigned int W_L1 =(unsigned int)  real_arg[5];
  unsigned int y_L1 =(unsigned int)  real_arg[6];
  unsigned int im2col =(unsigned int)  real_arg[7];
  int y_tile_w = 8;
  int y_tile_h = 8;
  int x_tile_w = 9;
  int x_tile_h = 9;
  int ch_in = 32;
  int ch_out = 32;
  pi_cl_team_barrier(0);


  //////////////////////////
  // Variable declaration //
  //////////////////////////
  volatile int p_r, p_l, p_t, p_b;
  int dma_evt = mchan_alloc();

  dma_memcopy_3d(
  W, 
  W_L1, 
  ch_in * DIM_KERNEL_X * DIM_KERNEL_Y,
  ch_out, 
  ch_in * DIM_KERNEL_X * DIM_KERNEL_Y, 
  1, 
  &dma_evt 
  );
  mchan_barrier(dma_evt);

  // tile loop nest
  for(int h_tile = 0; h_tile < 2; h_tile++) 
  {
    for(int w_tile = 0; w_tile < 2; w_tile++) 
    {
      dma_memcopy_3d(
        x + w_tile * ch_in * (x_tile_w - 2) + h_tile * ch_in * DIM_IM_IN_X * (x_tile_h - 2), 
        x_L1, 
        ch_in * DIM_IM_IN_X, 
        x_tile_h,
        ch_in * x_tile_w, 
        1, // dir
        &dma_evt // copy
        );
      mchan_barrier(dma_evt);

      p_r = 0; p_l = 0; p_t = 0; p_b = 0;
      if (h_tile == 0)
        p_t = 1;
      if (w_tile == 0)
        p_l = 1;
      if (h_tile == 2-1)
        p_b = 1;
      if (w_tile == 2-1)
        p_r = 1;
      pi_cl_team_barrier(0);

      pulp_nn_conv(
        x_L1,
        im2col,
        NULL,
        y_L1,
        W_L1,
        OUT_SHIFT,
        x_tile_w,
        x_tile_h,
        ch_in,
        y_tile_w,
        y_tile_h,
        ch_out,
        DIM_KERNEL_X,
        DIM_KERNEL_Y,
        p_t,
        p_b,
        p_l,
        p_r,
        STRIDE_X,
        STRIDE_Y);
      pi_cl_team_barrier(0);

      dma_memcopy_3d(
        y + w_tile * ch_out * y_tile_w + h_tile * ch_out * DIM_IM_OUT_X * y_tile_h, // ext
        y_L1, // loc
        ch_out * DIM_IM_OUT_X,
        y_tile_h, 
        ch_out * y_tile_w, 
        0,
        &dma_evt 
        );
      mchan_barrier(dma_evt);
    }
  }
  mchan_free(dma_evt);
}
