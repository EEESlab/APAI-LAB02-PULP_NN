/*
 * layer_template.c
 * Alessio Burrello <alessio.burrello@unibo.it>
 *
 * Copyright (C) 2018-2020 University of Bologna
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License. 
 */

#include "mchan_test.h"
#include "pulp_nn_kernels.h"
#include "layerConv.h"

void layerConv_Tiling(
  void *args
) {
  unsigned int *real_arg = (unsigned int *) args;
  unsigned int x =(unsigned int)  real_arg[0];
  unsigned int W =(unsigned int)  real_arg[1];
  unsigned int y =(unsigned int)  real_arg[2];
  unsigned int x_L1 =(unsigned int)  real_arg[4];
  unsigned int W_L1 =(unsigned int)  real_arg[5];
  unsigned int y_L1 =(unsigned int)  real_arg[6];
  unsigned int im2col =(unsigned int)  real_arg[7];
  int y_tile_w = 8;
  int y_tile_h = 8;
  int x_tile_w = 9;
  int x_tile_h = 9;
  int ch_in = 32;
  int ch_out = 32;
  int dma_evt = mchan_alloc();
  pi_cl_team_barrier(0);

  dma_memcopy_3d(
    W, // ext
    W_L1, 
    ch_in * DIM_KERNEL_X * DIM_KERNEL_Y,
    ch_out, 
    ch_in * DIM_KERNEL_X * DIM_KERNEL_Y, 
    1, // dir
    &dma_evt // copy
    );
  mchan_barrier(dma_evt);

  dma_memcopy_3d(
    x, // ext
    x_L1, // loc
    ch_in * DIM_IM_IN_X, 
    x_tile_h,
    ch_in * x_tile_w, 
    1, // dir
    &dma_evt // copy
    );
  mchan_barrier(dma_evt);

  //////////////////////////
  // Variable declaration //
  //////////////////////////
  volatile int p_r, p_l, p_t, p_b;
  int iter;
  unsigned int x_L1_shifted = x_L1 + ch_in * x_tile_w * x_tile_h;
  unsigned int y_L1_shifted = y_L1 + ch_out * y_tile_w * y_tile_h;
  int buffer_flag = 0;
  unsigned int x_L1_tiling = buffer_flag ? x_L1 : x_L1_shifted;
  unsigned int y_L1_tiling = buffer_flag ? y_L1_shifted : y_L1;
  int w_tile_load = 0; int h_tile_load = 0;
  int w_tile_exec = 0; int h_tile_exec = 0;

  for(int iter = 0; iter < 4; iter++) 
  {
    w_tile_load++;
    if (w_tile_load == 2)
    {
      w_tile_load = 0;
      h_tile_load++;
    }
    if (iter < 4)
    {
      dma_memcopy_3d(
        x + w_tile_load * ch_in * (x_tile_w - 2) + h_tile_load * ch_in * DIM_IM_IN_X * (x_tile_h - 2), // ext
        x_L1_tiling, // loc
        ch_in * DIM_IM_IN_X, 
        x_tile_h,
        ch_in * x_tile_w, 
        1, // dir
        &dma_evt // copy
        );
    }

    buffer_flag = !buffer_flag;
    x_L1_tiling = buffer_flag ? x_L1 : x_L1_shifted;
    p_r = 0; p_l = 0; p_t = 0; p_b = 0;
    if (h_tile_exec == 0)
      p_t = 1;
    if (w_tile_exec == 0)
      p_l = 1;
    if (h_tile_exec == 2-1)
      p_b = 1;
    if (w_tile_exec == 2-1)
      p_r = 1;
    pi_cl_team_barrier(0);

    pulp_nn_conv(
        x_L1_tiling,
        im2col,
        NULL,
        y_L1_tiling,
        W_L1,
        OUT_SHIFT,
        x_tile_w,
        x_tile_h,
        ch_in,
        y_tile_w,
        y_tile_h,
        ch_out,
        DIM_KERNEL_X,
        DIM_KERNEL_Y,
        p_t,
        p_b,
        p_l,
        p_r,
        STRIDE_X,
        STRIDE_Y);
    pi_cl_team_barrier(0);

    // wait for DMA write/read
    mchan_barrier(dma_evt);
    dma_memcopy_3d(
      y + w_tile_exec * ch_out * y_tile_w + h_tile_exec * ch_out * DIM_IM_OUT_X * y_tile_h, // ext
      y_L1_tiling, // loc
      ch_out * DIM_IM_OUT_X,
      y_tile_h, 
      ch_out * y_tile_w, 
      0,
      &dma_evt 
      );
    y_L1_tiling = buffer_flag ? y_L1_shifted : y_L1;
    w_tile_exec++;
    if (w_tile_exec == 2)
    {
      w_tile_exec = 0;
      h_tile_exec++;
    }
    pi_cl_team_barrier(0);
  }
  
  // wait for final write
  mchan_barrier(dma_evt);
  mchan_free(dma_evt);
}
